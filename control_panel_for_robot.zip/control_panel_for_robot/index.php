<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$database = 'control_panel';

// Create connection
$connect = mysqli_connect($servername, $username, $password,$database);
// Check connection
if (!$connect) {
	 die("Connection failed: " . mysqli_connect_error());

}
else{
echo "Connected successfully";


}
?>

<!DOCTYPE html>
<html>
<head>
<style>
header{
  background-image: url("Pictures/good.jpg");
   background-attachment: fixed;
	background-size: auto;}

 footer{
background-image: url("Pictures/good.jpg");
   background-attachment: fixed;
	background-size: auto;}
/* header */
#home{
width:250px;
 height:250px;}


#mainbody {
line-height: 1.6;
height: 100vh;	
}
.button1{
  border: none;
  color: white;
  padding: 15px 27px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  background-color: #333;
}
.button1 input[type=button]:hover{
  background-color: #111;
}
.button1:hover { 
  background-color: #000;
}
.button{
  border: none;
  color: white;
  padding: 15px 27px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  background-color: red;
}
.button input[type=button]:hover{
  background-color: #111;
}
.button:hover { 
  background-color: #000;
}
body  {
  font-family: Arial, Helvetica, sans-serif;
}

#facebook{
width:30px;
height:30px;
padding-right:5px;
padding-left:30px;	
}
#twitter{
width:30px;
height:30px;
padding-right:5px;	
}
#email{
width:30px;
height:30px;
}


.priv{
text-align:right;}


.section {
  text-align:center;
  font-size: 3em;
}


.fade-in{
animation:fadein 3s;		
}
@keyframes fadein{
	from{
		opacity:0;
	}
	to[
	opacity:1;
}}


</style>
<meta charset="utf-8">
<title>IOS</title>

<link rel="shortcut icon" type="images/x-icon" href="Pictures/logo1.png"/>
</head>
<body class="mainbody">
<header>
<div> 
<a href="index.html"><img src="Pictures/logo1.png" id="home" alt="Website logo"></a>
<br><br>

</div>

</header>
<!-- the end of the header -->
<main>
<div id="fullpage">


 <div class="section fade-in div1">
		<h4> Welcome </h4>
	

<form action="robot.php" method="POST">
 <button  type="submit" value="Forwards" onclick="openWin1()" class="button1" name="F">Forwards</button>
</form>
</div>


 <div class="section fade-in">
<form action="robot.php" method="POST">
<button  type="submit"  value="Left" onclick="openWin()" class="button1" name="L">Left</button>
<button  type="submit"  value="STOP" onclick="openWin()" class="button" name="S">STOP</button>
<button  type="submit"  value="Right" onclick="openWin()" class="button1" name="R">Right</button>
</form>
</div>

 <div class="section fade-in">
<form action="robot.php" method="POST">
<button  type="submit"  value="Backwards" onclick="openWin2()" class="button1" name="B">Backwards</button>
</form>
</div>

<br>
</div>

<!-- The end of the main -->
</main>
<footer>
<br>
<a href="" target="_blank"><img src="Pictures/face.png" id="facebook" alt="facebook logo"></a>
<a href=""><img src="Pictures/twitter.png" id="twitter" alt="twitter logo"></a>
<a href="https://accounts.google.com" ><img src="Pictures/mail.png" id="email" alt="mail logo"></a>

<br><br><br><br><br>
<div class="priv">
<a href="" >  privacy | terms </a>
<br><br>
</div>


</footer>

</body>
</html>
<?php

mysqli_close($connect);
?>