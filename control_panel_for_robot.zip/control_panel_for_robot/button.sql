-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 03 يوليو 2020 الساعة 05:39
-- إصدار الخادم: 10.4.10-MariaDB
-- PHP Version: 7.2.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `control_panel`
--

-- --------------------------------------------------------

--
-- بنية الجدول `button`
--

CREATE TABLE `button` (
  `id` int(11) NOT NULL,
  `stop` varchar(255) NOT NULL,
  `back` varchar(255) NOT NULL,
  `forward` varchar(255) NOT NULL,
  `righ` varchar(255) NOT NULL,
  `lef` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `button`
--

INSERT INTO `button` (`id`, `stop`, `back`, `forward`, `righ`, `lef`) VALUES
(1, 'S', 'B', 'F', 'R', 'L'), --here I am inserted manually
(2, '', '', 'F', '', ''),
(3, '', '', '', '', 'L'),
(4, '', '', '', '', 'L'),
(5, '', '', 'F', '', ''),
(6, '', '', 'F', '', ''),
(7, 'S', '', '', '', ''),
(8, '', '', '', '', 'L'),
(9, '', '', '', 'R', ''),
(10, '', 'B', '', '', ''),
(11, 'S', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `button`
--
ALTER TABLE `button`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `button`
--
ALTER TABLE `button`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
